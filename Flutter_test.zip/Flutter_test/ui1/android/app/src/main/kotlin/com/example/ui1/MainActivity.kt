package com.example.ui1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
